export declare const Exposed: () => import("react/jsx-runtime").JSX.Element;
