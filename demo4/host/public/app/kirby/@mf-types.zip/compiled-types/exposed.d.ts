import ReactDOM from "react-dom/client";
export declare const renderToContainer: (rootEl: Element) => ReactDOM.Root;
